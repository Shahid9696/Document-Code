package com.newgen.util;

import java.io.File;
import java.io.RandomAccessFile;
import java.nio.channels.OverlappingFileLockException;

public class InstanceChecker {
	
	public static void CheckRunningInstances()
	{			
		try 
		{
			AddShutdownHookSample jvmHook = new AddShutdownHookSample();
			File securityFile = new File("./security.dat");
			securityFile = securityFile.getAbsoluteFile();
			
			if (securityFile.exists()) 
			{
				System.out.println("One Instance of this service is already running...");
				System.exit(1);
			}
			else
			{
				if (securityFile.createNewFile()) 
				{ 
					RandomAccessFile randomAccessFile=new RandomAccessFile(securityFile, "rw");
					
									
					AddShutdownHookSample.channel =  randomAccessFile.getChannel();
					try 
					{
						AddShutdownHookSample.lock = AddShutdownHookSample.channel.tryLock();
					} 
					catch (OverlappingFileLockException e) 
					{
						
					}
					finally
					{
						randomAccessFile.close();
					}
				}
			}				
			jvmHook.attachShutDownHook(securityFile);
		}		
		catch (Exception e) 
		{
			
			
		}			
	}

}
