/*
Group						: Application Projects 2
Product / Project			: BOA
Module                      : Java File
File Name					: 
Author                      : 
Date written (DD/MM/YYYY)   : 
Date modified (DD/MM/YYYY)  : 
Description                 : Java file to Cheque Book Upload.
-------------------------------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------------------------------
CHANGE HISTORY 
-------------------------------------------------------------------------------------------------------------------
BUG ID                Date			Change By			Change Description 

-------------------------------------------------------------------------------------------------------------------
*/

package com.newgen.util;

public class SMSAutoServiceException extends Exception 
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public SMSAutoServiceException(String msg) 
	{
		super(msg);
	}
}
