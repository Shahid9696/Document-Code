/*
Group                       : Application Projects 2
Product / Project           : 
Module                      : 
File Name                   : 
Author                      : 
Date written (DD/MM/YYYY)   : 
Date modified (DD/MM/YYYY)  : 
Description                 : 
-------------------------------------------------------------------------------------------------------------------
 */

package com.newgen.util;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import com.newgen.wfdesktop.xmlapi.WFCallBroker;

import org.apache.commons.lang.StringEscapeUtils;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import com.newgen.dmsapi.DMSXmlList;
import com.newgen.dmsapi.DMSXmlResponse;
import com.newgen.omni.wf.util.app.NGEjbClient;
import com.newgen.omni.wf.util.excp.NGException;

import java.util.*;

import java.io.*;
import java.net.*;
import java.nio.channels.OverlappingFileLockException;
import java.sql.Timestamp;

public class SMSAutoService implements Runnable
{
	private  Logger mLogger;

	private String cabinetName;
	 String username;
	 String password;
	private String jtsIP;
	private String jtsPort;
	String sessionID;
	private String ENDPOINTURL;
	private String SMSResponse;
	private String SuccessCode;
	private String FailCode;
	private String SuccessResponseCode;
	private String TableName;
	private String ColNames;
	public String userID = "";
	private String sessionId = "";
	private int sleepTime = 0;
	private int sleepTimeToWait = 0;
	boolean bRun = true;
	boolean bMatch = true;
	String lastProcessInstanceId ="";
	String lastWorkItemId = "";
	GenerateXml objXmlGen = new GenerateXml();
	NGEjbClient ngEjbClient;
	String strQuery1="";

	String TimeToRun1="";
	String TimeToRun2="";
	String TimeToRun3="";

	String TimeToRunFlag1="";
	String TimeToRunFlag2="";
	String TimeToRunFlag3="";

	String inputDate = "";
	String XMLExtra2 = "";
	XMLParser lobjXMLParser = new XMLParser();
	String fetch_date="";
	Runtime r = Runtime.getRuntime();
	private static String Requireddateformat ="";
	public  boolean keepRunning = true;
	boolean checkThreads = false;

	public static void main(String[] args)
	{
		// added by abhishek to call function which checks the running threads start
		CheckRunningInstances();
		//added by abhishek to call function which checks the running threads end
		SMSAutoService x = new SMSAutoService();  
		Thread t1 =new Thread(x);
		t1.start();
	}
	public static void CheckRunningInstances()
	{			
		try 
		{
			AddShutdownHookSample jvmHook = new AddShutdownHookSample();
			File securityFile = new File("./security.dat");
			securityFile = securityFile.getAbsoluteFile();
			
			if (securityFile.exists()) 
			{
				
				System.exit(1);
			}
			else
			{
				if (securityFile.createNewFile()) 
				{ 
					RandomAccessFile randomAccessFile=new RandomAccessFile(securityFile, "rw");
					
									
					AddShutdownHookSample.channel =  randomAccessFile.getChannel();
					try 
					{
						AddShutdownHookSample.lock = AddShutdownHookSample.channel.tryLock();
					} 
					catch (OverlappingFileLockException e) 
					{
						
					}
					finally
					{
						randomAccessFile.close();
					}
				}
			}				
			jvmHook.attachShutDownHook(securityFile);
		}		
		catch (Exception e) 
		{
			
			
		}			
	}
	
	//long start,end;

	/*public ThreadClient()
	{
		try
		{			
			setProperties(); // To read the configuration file.
			objXmlGen = new GenerateXml();	
			//start=System.currentTimeMillis();   
		}
		catch(Exception ex)
		{
			mLogger.info("Error during reading the configuration file.");
		}

		mLogger.info("Inside ThreadClient() constructor.");
	}*/


	public void setProperties()
	{
		mLogger = Logger.getLogger("mLogger");
		createLogFile();
		try
		{
			ngEjbClient = NGEjbClient.getSharedInstance();
		}
		catch(Exception e)
		{
		}
		mLogger.info("Reading Configuration Parameters Starts");
		try 
		{

			Properties p = null;
			p = new Properties();
			String strPropertyPath = "configFiles"+File.separator+"Config.properties";
			p.load(new FileInputStream(strPropertyPath));
			
			strQuery1 = p.getProperty("Query1");
			username = p.getProperty("username");
			password = p.getProperty("password");
			cabinetName = p.getProperty("CabinetName");
			jtsIP = p.getProperty("JTSIP");
			jtsPort = p.getProperty("JTSPort");

			ENDPOINTURL = p.getProperty("ENDPOINTURL");
			SuccessResponseCode = p.getProperty("SuccessResponseCode");
			TableName = p.getProperty("TableName");
			ColNames = p.getProperty("ColNames");
			SuccessCode = p.getProperty("SuccessCode");
			FailCode = p.getProperty("FailCode");

			sleepTime = Integer.parseInt(p.getProperty("sleepTime"));
			sleepTimeToWait = Integer.parseInt(p.getProperty("sleepTimeToWait"));

			TimeToRun1 = p.getProperty("TimetoRun1");
			TimeToRun2 = p.getProperty("TimetoRun2");
			TimeToRun3 = p.getProperty("TimetoRun3");

			TimeToRunFlag1 = p.getProperty("TimetoRunToGenerate1");
			TimeToRunFlag2 = p.getProperty("TimetoRunToGenerate2");
			TimeToRunFlag3 = p.getProperty("TimetoRunToGenerate3");


			fetch_date=p.getProperty("FETCH_DATE");
			mLogger.info("from_date "+fetch_date);

			mLogger.info("Query "+strQuery1);

			mLogger.info("CabinetName=" + cabinetName+ "\n" +
					"JTSIP=" + jtsIP+ "\n" +
					"JTSPort=" + jtsPort+ "\n" +
					"sleepTime=" + sleepTime+ "\n" +
					"query=" + strQuery1 + "\n");

		} 
		catch (FileNotFoundException e) 
		{
			mLogger.error("Config.properties not found. "+e);
		}
		catch (IOException e) 
		{
			mLogger.error("Config.properties Load/Read Failed with IOException. "+e);
		}
		mLogger.info("Reading Configuration Parameters Completed");
	}

	Logger mLogger()
	{
		return mLogger;
	}


	public  void createLogFile()
	{
		try
		{
			Date date = new Date();
			DateFormat logDateFormat = new SimpleDateFormat("dd-MM-yyyy");
			String dynamicLog = "Log/"+logDateFormat.format(date)+"/SMSAutoServer.xml"; 

			Properties p = new Properties();
			p.load(new FileInputStream("log4j.properties"));  
			String orgFileName = p.getProperty("log4j.appender.mLogger.File");

			if(!(orgFileName==null || orgFileName.equalsIgnoreCase("")))
			{
				dynamicLog = "Log/"+logDateFormat.format(date)+orgFileName.substring(orgFileName.lastIndexOf("/"));
			}

			File d = new File("Log/"+logDateFormat.format(date));
			d.mkdirs();
			File fl = new File(dynamicLog);
			if(!fl.exists())
				fl.createNewFile();

			p.put("log4j.appender.mLogger.File", dynamicLog ); // overwrite "log.dir"  
			PropertyConfigurator.configure(p); 
		}
		catch(Exception e)
		{
			mLogger.info("Eexception in creating dynamic log :"+e);
			mLogger.error("Eexception in creating dynamic log :"+e);
		}
	}

	public void run() {
		try {
			setProperties();
			System.out.println("Thread is running.");	
            bMatch = false;
			Calendar cal = Calendar.getInstance();
			SimpleDateFormat sdf = new SimpleDateFormat("HH:mm");
			String time = sdf.format(cal.getTime());
			System.out.println("Current System Time = " + time);
			            
			            if(time.equals(TimeToRun1))
			{
				bMatch = true;
			                    TimeToRunFlag1="Y";
			}
			            else if(time.equals(TimeToRun2))
			{
				bMatch = true;
			                    TimeToRunFlag2="Y";
			}
			            else if(time.equals(TimeToRun3))
			{
				bMatch = true;
			                    TimeToRunFlag3="Y";
			}
			if (connectToServer()) {
				String str = connectToWorkFlow("Y");
				String temp[] = str.split("~");
				if (!temp[0].equals("0")) {
					Thread.sleep(10000);
					if (reconnectToWorkflow()) {
						;
					}
				}
			}
		} catch (Exception ex) {
			mLogger.info(ex.toString());
		}

		while (keepRunning) {
			r.gc(); // garbage collector
			mLogger.info("Start of thread for " + GlobalVar.titleName);
			System.out.println("Start of thread for " + GlobalVar.titleName);
			try {
				int iRet = this.loadAndProcessWorkItems();
				if (iRet == 11) {
					if (reconnectToWorkflow()) {
						this.loadAndProcessWorkItems();
					}
				}
				if (keepRunning) {
					mLogger.info("\n" + GlobalVar.titleName + " is sleeping\n");
					System.out.println(GlobalVar.titleName + " is sleeping");
					waiteloop(GlobalVar.pollInterval * 100);
				}
			} catch (Exception ex) {
				mLogger.info(ex.toString());
			}
			mLogger.info("End of thread for " + GlobalVar.titleName);
			System.out.println("End of thread for " + GlobalVar.titleName);
		}
		// added for shutdown hook
		
		// added by abhishek to set status flag of running threads to true start
		 checkThreads = true;
		// added by abhishek to set status flag of running threads to true end
		
		try {
			disconnectFromWorkFlow();
			disconnectFromServer();
		} catch (Exception ex) {
			mLogger.info(ex.toString());
		}
	}
	private int loadAndProcessWorkItems() throws NumberFormatException, IOException, Exception 
	{
		// TODO Auto-generated method stub
		createLogFile();
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMddHHmmss");
		Date date = new Date();
		String fetchdate = dateFormat.format(date).toString();
		mLogger.info(fetchdate);

		SimpleDateFormat dateFormat2 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		XMLExtra2 = dateFormat2.format(date).toString();

		String requiredYear = fetchdate.substring(2,4);
		String requiredMonth = fetchdate.substring(4,6);
		String requiredDay = fetchdate.substring(6,8);
		String requiredHours = Integer.toString(Integer.parseInt(fetchdate.substring(8,10))+ 12);
		String requiredMin = fetchdate.substring(10,12);
		String requiredSecond = fetchdate.substring(12,14);

		Requireddateformat = requiredDay + requiredMonth + requiredYear + requiredHours + requiredMin + requiredSecond ;

		if(TimeToRunFlag1.equalsIgnoreCase("Y"))
		{
			GenerateFileTimeToRun1();
		}


		try
		{
			Thread.sleep(sleepTimeToWait);
		}
		catch(Exception thread)
		{
			mLogger.info("Thread = " + thread);
		}
		return 0;
	}

	private void GenerateFileTimeToRun1()
	{

		try
		{

			String fetchIInputXML = objXmlGen.ExecuteQuery_APSelectWithColumnNames(strQuery1,cabinetName,sessionID);
			mLogger.info("Supriyo Input XML before----->"+fetchIInputXML);
			String fetchIOutputXML = WFCallBroker.execute(fetchIInputXML,jtsIP,Integer.parseInt(jtsPort),1);
			mLogger.info("Supriyo Output XML before----->"+fetchIOutputXML);
			fetchIOutputXML = fetchIOutputXML.replaceAll("&","and");
			fetchIOutputXML = escapeXMLString(fetchIOutputXML,"Value");
			mLogger.info("Supriyo Output XML after----->"+fetchIOutputXML);        


			DMSXmlList DMSGetWorkItemXmlList = null;
			String sReplacedXMLTag = "";
			ArrayList<String> ArrLstTableValues = new ArrayList<String>();
			String[] sArrSplitIT = null;

			String sSplit = "";
			DMSXmlResponse DMSGetWorkItemXmlResponse = null;
			DMSGetWorkItemXmlResponse = new DMSXmlResponse(fetchIOutputXML);
			mLogger.info("Output XML :\n" + DMSGetWorkItemXmlResponse + "\n");
			if (DMSGetWorkItemXmlResponse.getVal("MainCode").equals("0")) {
				mLogger.info("Data fetched successfully");
				DMSGetWorkItemXmlList = DMSGetWorkItemXmlResponse.createList("Records", "Record");
				for (int DMSGetWorkItemXmlLoopCnt = 0; DMSGetWorkItemXmlList.hasMoreElements(true); DMSGetWorkItemXmlList.skip(true), DMSGetWorkItemXmlLoopCnt++) {
					sReplacedXMLTag = DMSGetWorkItemXmlList.toString().replaceAll("<Sno>", "").replaceAll("</Sno>", "#:;#").replaceAll("<Alert_name>", "").replaceAll("</Alert_name>", "#:;#").replaceAll("<Alert_code>", "").replaceAll("</Alert_code>", "#:;#").replaceAll("<Mobile_no>", "").replaceAll("</Mobile_no>", "#:;#").replaceAll("<Alert_text>", "").replaceAll("</Alert_text>", "#:;#").replaceAll("<Alert_Status>", "").replaceAll("</Alert_Status>", "#:;#").replaceAll("<wi_Name>", "").replaceAll("</wi_Name>", "#:;#").replaceAll("<Record>", "").replaceAll("</Record>", "").trim();
					ArrLstTableValues.add(DMSGetWorkItemXmlLoopCnt, sReplacedXMLTag.trim());
				}
			} else if (DMSGetWorkItemXmlResponse.getVal("MainCode").equals("18")) {
				mLogger.info("Record not available....\n");
				mLogger.info("Record not available....");
			} else if (DMSGetWorkItemXmlResponse.getVal("MainCode").equals("15")) {
				mLogger.info("Session out / sysnax error : \n" + strQuery1 + "\n");
				mLogger.info("Session out / sysnax error ");
			}

			mLogger.info("Deepak ArrLstTableValues : "+ ArrLstTableValues.toString());
			if (!ArrLstTableValues.toString().equalsIgnoreCase("[]")) {


				for (int iIncCnt = 0; iIncCnt < ArrLstTableValues.size(); iIncCnt++) {

					sSplit = ArrLstTableValues.get(iIncCnt).toString().trim();
					sArrSplitIT = sSplit.split("#:;#");

					String sALERT_INDEX = sArrSplitIT[0].toString().trim();
					String sALERT_NAME = sArrSplitIT[1].toString().trim();
					String sALERT_CODE = sArrSplitIT[2].toString().trim();
					String sMOBILE_NO = sArrSplitIT[3].toString().trim();
					String sALERT_TEXT = sArrSplitIT[4].toString().trim();
					String sALERT_STATUS = sArrSplitIT[5].toString().trim();
					String sWORKITEM_NO = sArrSplitIT[6].toString().trim();

					Timestamp localTimestamp = new Timestamp(System.currentTimeMillis());
				      Random rdn = new Random();
				      String msgID = "CAS" + localTimestamp.getTime()+rdn.nextInt(100);
				      
					String sInputXML = "<?xml version='1.0' encoding='UTF-8' standalone='yes'?>"
							+ "<EE_EAI_MESSAGE>"
							+ "<EE_EAI_HEADER>"
							+ "<MsgFormat>SEND_ADHOC_ALERT</MsgFormat>"
							+ "<MsgVersion>0000</MsgVersion>"
							+ "<RequestorChannelId>CAS</RequestorChannelId>"
							+ "<RequestorUserId>OT_ADHOC_ALERT</RequestorUserId>"
							+ "<RequestorLanguage>E</RequestorLanguage>"
							+ "<RequestorSecurityInfo>Secure</RequestorSecurityInfo>"
							+ "<ReturnCode>0000</ReturnCode>"
							+ "<ReturnDesc></ReturnDesc>"
							+ "<MessageId>"+msgID+"</MessageId>"
							+ "<Extra1>"
							+ "</Extra1>"
							+ "<Extra2>2017-04-26 09:32:44</Extra2>"
							+ "</EE_EAI_HEADER>"
							+ "<SendAdhocAlert>"
							+ "<BankId>RAK</BankId>"
							+ "<CustId>CAS_ADHOC_ALERT</CustId>"
							+ "<AlertMsgDelRec>"
							+ "<CustGenInfo>"
							+ "<CorpId>CAS_ADHOC_ALERT</CorpId>"
							+ "<EbankingUserId>CAS_ADHOC_ALERT</EbankingUserId>"
							+ "<CustHostId>CRM</CustHostId>"
							+ "<CustDCId>CRM</CustDCId>"
							+ "<ChannelId>SMS</ChannelId>"
							+ "<LangId>001</LangId>"
							+ "<CustType>E</CustType>"
							+ "<CustSubType>R</CustSubType>"
							+ "</CustGenInfo>"
							+ "<AlertInfo>"
							+ "<AlertName>"+sALERT_NAME+"</AlertName>"
							+"<AlertSubj>CASSMS</AlertSubj>"
							+"<AlertMsg>"+sALERT_TEXT+"</AlertMsg>"
							+"<Addr>"+sMOBILE_NO+"</Addr>"
							+"<Encoding>UTF-8</Encoding>"
							+"<isTrusted>Y</isTrusted>"
							+"</AlertInfo>"
							+"</AlertMsgDelRec>"
							+"</SendAdhocAlert>"
							+"</EE_EAI_MESSAGE>";

					mLogger.info("InputXML:: "+ sInputXML);

					SMSResponse = SMSWebservice(sInputXML);
					String whereCondition = "ALERT_INDEX ="+ "'"+sALERT_INDEX+"'";

					if(SMSResponse.equalsIgnoreCase(SuccessResponseCode))
					{   
						updateStatus("'"+SuccessCode+"'",whereCondition);
					}
					else
					{
						updateStatus("'"+FailCode+"'",whereCondition);
					}

				}

			}
		} 
		catch (IOException ex) 
		{
			mLogger.info("IO Exception = " + ex);
		} 
		catch (Exception ex) 
		{
			mLogger.info("Error is saving Workitem Data = " + ex);
		}

	}

	private void updateStatus(String updatedValues, String whereClause) throws Exception
	{

		try 
		{
			String updateIInputXML = objXmlGen.ExecuteQuery_APUpdate(TableName, ColNames, updatedValues, whereClause, cabinetName, sessionId);
			mLogger.info("Supriyo Input XML before----->"+updateIInputXML);
			String updateIOutputXML = WFCallBroker.execute(updateIInputXML,jtsIP,Integer.parseInt(jtsPort),1);
			String mainCode2 = getTagValue(updateIOutputXML, "MainCode");
			mainCode2 = mainCode2.trim();
			mLogger.info("main code: " + mainCode2);

			if (!mainCode2.equalsIgnoreCase("0")) 
			{
				mLogger.info("Error during updation.");
				//System.exit(1);
			}

		} catch (IOException ex) {
			mLogger.info("Exception:"+ex.getMessage());
			ex.printStackTrace();
		}

	}

	void waiteloop(long wtime) {
		try {
			for (int i = 0; i < 10; i++) {
				Thread.yield();
				Thread.sleep(wtime / 10);
				if (!keepRunning) {
					break;
				}
			}
		} catch (InterruptedException e) {
			mLogger.info(e.toString());
			Thread.currentThread().interrupt();
		}
	}
	private String getTagValue(Node node, String tag) 
	{
		// TODO Auto-generated method stub
		String value = "";
		NodeList nodeList = node.getChildNodes();
		int length = nodeList.getLength();

		for (int i = 0; i < length; ++i) 
		{
			Node child = nodeList.item(i);
			if (child.getNodeType() == Node.ELEMENT_NODE && child.getNodeName().equalsIgnoreCase(tag)) 
			{
				return child.getTextContent();
			}

		}
		//mLogger.info(tag+":"+value);
		return value;
	}

	public String connectToWorkFlow(String forceful) {
		int i = -9;
		String desc = null;
		String xmlInput = null;
		String xmlOutput = null;
		try {
			xmlInput = objXmlGen.get_WMConnect_Input(this.cabinetName, this.username, this.password, forceful);

			//System.out.println(xmlInput);

			xmlOutput = this.executeWithoutInLog(xmlInput);
			//System.out.println(xmlOutput);

			lobjXMLParser.setInputXML(xmlOutput);
			String s9 = lobjXMLParser.getValueOf("Option");
			if (!s9.equalsIgnoreCase("WMConnect")) {
				return "-9~Invalid Workflow Server IP and Port are registered.";
			}
			String s6 = lobjXMLParser.getValueOf("MainCode");
			i = Integer.parseInt(s6);
			if (i == 0) {
				this.sessionID = lobjXMLParser.getValueOf("SessionID");
				this.userID = lobjXMLParser.getValueOf("ID");

			}
			else {
				String s7 = lobjXMLParser.getValueOf("SubErrorCode");
				desc = lobjXMLParser.getValueOf("Description");
				i = Integer.parseInt(s7);
			}
		}
		catch (Exception e) {
			mLogger.info(e.toString());
			//
		}
		return i + "~" + desc;
	}

	public String executeWithoutInLog(String inXml) {
		try {
			String outXml = ngEjbClient.makeCall(inXml);
			if (GlobalVar.printScreenflag == true) {
				mLogger.info(outXml);
			}
			return outXml;
		}
		catch (NGException ngE) {
			mLogger.info(ngE.toString());
			disconnectFromServer();
			if (connectToServer()) {
				try {
					String outXml = ngEjbClient.makeCall(inXml);
					if (GlobalVar.printScreenflag == true) {
						mLogger.info(outXml);
					}
					return outXml;
				}
				catch (NGException ngE1) {
					mLogger.info(ngE1.toString());
				}
				catch (Exception ex) {
					mLogger.info(ex.toString());
				}
			}
			return "";
		}
	}

	private boolean reconnectToWorkflow() {
		try {
			disconnectFromWorkFlow();
			disconnectFromServer();
		} catch (Exception ex) {
			mLogger.info(ex.toString());
			return false;
		}
		try {
			if (connectToServer()) {
				String str = connectToWorkFlow("N");
				String temp[] = str.split("~");
				if (!temp[0].equals("0")) {
					Thread.sleep(10000);
					if (keepRunning) {
						if (reconnectToWorkflow()) {
							;
						}
					}
				}
			} else {
				return false;
			}
		} catch (Exception ex) {
			mLogger.info(ex.toString());
			return false;
		}
		return true;
	}

	public void disconnectFromWorkFlow() throws NGException {
		String str_inxml = objXmlGen.get_WMDisConnect_Input(this.cabinetName, this.sessionID);
		execute(str_inxml);
	}


	public void disconnectFromServer() {
		try {
			ngEjbClient = null;
		}
		catch (Exception e) {
			mLogger.info(e.toString());
		}
	}

	public String execute(String inXml) {
		try {
			if (GlobalVar.printScreenflag == true) {
				mLogger.info(inXml);
			}
			String outXml = ngEjbClient.makeCall(inXml);
			if (GlobalVar.printScreenflag == true) {
				mLogger.info(outXml);
			}
			return outXml;
		}
		catch (NGException ngE) {
			mLogger.info(ngE.toString());
			disconnectFromServer();
			if (connectToServer()) {
				try {
					if (GlobalVar.printScreenflag == true) {
						mLogger.info(inXml);
					}
					String outXml = ngEjbClient.makeCall(inXml);
					if (GlobalVar.printScreenflag == true) {
						mLogger.info(outXml);
					}
					return outXml;
				}
				catch (NGException ngE1) {
					mLogger.info(ngE1.toString());
				}
				catch (Exception ex) {
					mLogger.info(ex.toString());
				}
			}
			return "";
		}
	}
	private Document getDocument(String xml) throws ParserConfigurationException, SAXException, IOException  
	{

		// Step 1: create a DocumentBuilderFactory
		DocumentBuilderFactory dbf =
				DocumentBuilderFactory.newInstance();

		// Step 2: create a DocumentBuilder
		DocumentBuilder db = dbf.newDocumentBuilder();

		// Step 3: parse the input file to get a Document object
		Document doc = db.parse(new InputSource(new StringReader(xml)));
		return doc;
	}

	private String getTagValue(String xml, String tag) throws ParserConfigurationException, SAXException, IOException 
	{
		Document doc = getDocument(xml);
		NodeList nodeList = doc.getElementsByTagName(tag);

		int length = nodeList.getLength();
		//mLogger.info("NodeList Length: " + length);

		if (length > 0) 
		{
			Node node =  nodeList.item(0);
			//mLogger.info("Node : " + node);
			if (node.getNodeType() == Node.ELEMENT_NODE) 
			{
				NodeList childNodes = node.getChildNodes();
				String value = "";
				int count = childNodes.getLength();
				for (int i = 0; i < count; i++) 
				{
					Node item = childNodes.item(i);
					if (item.getNodeType() == Node.TEXT_NODE) 
					{
						value += item.getNodeValue();
					}
				}
				return value;
			} 
			else if (node.getNodeType() == Node.TEXT_NODE) 
			{
				return node.getNodeValue();
			}

		}
		return "";
	}


	private int getMainCode(String xml) throws Exception 
	{
		String code = "";
		try
		{
			code = getTagValue(xml, "MainCode");			
		}
		catch (Exception e)
		{
			mLogger.info(e);
			throw e;
		}


		int mainCode = -1;
		try
		{
			mainCode = Integer.parseInt(code);
			mLogger.info("Main Code: " + mainCode);
		}
		catch (NumberFormatException e)
		{
			mainCode = -1;
		}

		return mainCode;

	}

	private boolean isSuccess(String xml) 
	{
		if (xml.substring(xml.indexOf("<MainCode>")+10,xml.indexOf("</MainCode>")).equals("0")) 
		{
			return true;
		} 
		else 
		{
			return false;
		}
	}

	private String escapeXMLString(String sInputXML,String sTagName) {//BOA-2014/001
		String sStartTag = "<"+sTagName+">";
		String sEndTag = "</"+sTagName+">";
		int iStartIndex = sInputXML.indexOf(sStartTag);
		int iEndIndex = sInputXML.indexOf(sEndTag);
		mLogger.info("StartTag:"+sStartTag+"\n EndTag:"+sEndTag);
		mLogger.info("StartTag index:"+iStartIndex+"\n EndTag index:"+iEndIndex);
		while (iStartIndex >= 0) {
			StringBuilder sbXML = new StringBuilder();
			sbXML.append(sInputXML.substring(0,iStartIndex+sStartTag.length()));
			String sStringToBeReplaced =sInputXML.substring(iStartIndex+sStartTag.length(), iEndIndex);
			if(sStringToBeReplaced.length()>0)
			{
				mLogger.info("Original value in XML tag:"+sStringToBeReplaced+":to be replaced with----->"+StringEscapeUtils.escapeXml(sStringToBeReplaced));
				//sInputXML=sInputXML.replaceFirst(sInputXML.substring(iStartIndex+sStartTag.length(), iEndIndex), StringEscapeUtils.escapeXml(sStringToBeReplaced));
				sbXML.append(StringEscapeUtils.escapeXml(sStringToBeReplaced));
				sbXML.append(sInputXML.substring(iEndIndex,sInputXML.length()));
				sInputXML = sbXML.toString();
				iEndIndex = iStartIndex+sStartTag.length() + StringEscapeUtils.escapeXml(sStringToBeReplaced).length()+sEndTag.length();
			}
			else
			{
				sbXML.append(sInputXML.substring(iEndIndex,sInputXML.length()));
				sInputXML = sbXML.toString();
				mLogger.info("else case iStartIndex:"+iStartIndex+"sStartTag.length:"+sStartTag.length());
				iEndIndex = iStartIndex+sStartTag.length();
			}
			//sbXML.append(sInputXML.substring(iEndIndex,sInputXML.length()));
			//sInputXML = sbXML.toString();
			iStartIndex = sInputXML.indexOf(sStartTag, iStartIndex + 1);
			iEndIndex = sInputXML.indexOf(sEndTag, iEndIndex+1);
			mLogger.info("StartTag index:"+iStartIndex+"\n EndTag index:"+iEndIndex);
		} 
		/*Replace escape character ">" by "&gt;"*/
		return sInputXML; 
	}

	public String SMSWebservice(String INPUTXML)
	{
		Map<String, String> intPropMap = new HashMap<String, String>();
		mLogger.info("SOAPResponse_xml" + INPUTXML);

		String filenamejks = "jssecacerts.jks";
		String workingDirectoryjks = System.getProperty("user.dir");
		String jksFile = workingDirectoryjks + File.separator + filenamejks;

		String filenameCacerts = "cacerts";
		String workingDirectoryCacerts = System.getProperty("user.dir");
		String cacertsFile = workingDirectoryCacerts + File.separator + filenameCacerts;


		intPropMap.put("JKSFILE",jksFile);
		intPropMap.put("CACERTSFILE",cacertsFile);
		intPropMap.put("ENDPOINTURL",ENDPOINTURL);

		String responseXML="";		
		String packageHndStr = "javax.net.ssl";
		System.setProperty("java.protocol.handler.pkgs", packageHndStr);		
		System.setProperty("Content-Type", "text/html");
		System.setProperty("Content-Type", "application/soap+xml; charset=utf-8");
		System.setProperty("javax.net.ssl.keyStore", intPropMap.get("JKSFILE"));		
		System.setProperty("javax.net.ssl.keyStoreType", "JKS");
		System.setProperty("javax.net.ssl.keyStorePassword", "changeit");		
		System.setProperty("javax.net.ssl.trustStore", intPropMap.get("CACERTSFILE"));
		System.setProperty("javax.net.ssl.trustStoreType",  java.security.KeyStore.getDefaultType());
		System.setProperty("javax.net.ssl.trustStorePassword", "changeit");
		System.setProperty("javax.net.debug", "all");
		System.setProperty("com.ibm.ssl.contextProvider", "IBMJSSE2");


		String outputString="";
		URL url=null;
		URLConnection connection=null;
		HttpURLConnection httpConn=null;
		ByteArrayOutputStream bout=null;
		InputStreamReader isr =null;
		BufferedReader in =null;
		OutputStream out =null;
		try
		{	
			String WSurl=  ENDPOINTURL;
			url = new URL(WSurl);
			connection = url.openConnection();
			mLogger.info("connected");
			httpConn = (HttpURLConnection)connection;			
			httpConn.setConnectTimeout(Integer.parseInt("10000"));
			httpConn.setReadTimeout(Integer.parseInt("20000"));			

			bout = new ByteArrayOutputStream();
			String ipXML = INPUTXML;
			ipXML=ipXML.replaceAll("plussign", "+");

			byte[] buffer = new byte[ipXML.length()];
			buffer = ipXML.getBytes(StandardCharsets.UTF_8);
			bout.write(buffer);
			byte[] b = bout.toByteArray();

			httpConn.setRequestProperty("Content-Length",String.valueOf(b.length));		
			httpConn.setRequestProperty("Content-Type","application/xml; charset=utf-8");

			httpConn.setRequestMethod("POST");
			httpConn.setDoOutput(true);
			httpConn.setDoInput(true);

			out = httpConn.getOutputStream();

			out.write(b);
			out.close();
			isr = new InputStreamReader(httpConn.getInputStream());
			in = new BufferedReader(isr);
			String responseString;
			while ((responseString = in.readLine()) != null) 
			{
				outputString = outputString + responseString;

			}
			
			responseXML=outputString;
			mLogger.info("outputString: "+responseXML);
		}
		catch(ConnectException e)
		{
			outputString="";
			responseXML=e.toString();
			mLogger.info("outputString: "+responseXML);
			mLogger.info("Exception Occured: "+e.getMessage());
			e.printStackTrace();
			
		}
		catch(SocketTimeoutException e)
		{
			outputString="";
			responseXML=e.toString();
			mLogger.info("outputString: "+responseXML);
			mLogger.info("Exception Occured: "+e.getMessage());
			e.printStackTrace();
		}
		catch(Exception e)
		{
			outputString="";
			responseXML=e.toString();
			mLogger.info("outputString: "+responseXML);
			mLogger.info("Exception Occured: "+e.getMessage());
			e.printStackTrace();
		}

		finally
		{
			try
			{
				httpConn.disconnect();
				bout.close();
				isr.close();
				in.close();
				out.close();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
		}

		return "Response.... " + responseXML;
	}
	
	public boolean connectToServer() {
		try {
			ngEjbClient = NGEjbClient.getSharedInstance();
			ngEjbClient.initialize(this.jtsIP, String.valueOf(this.jtsPort), "JTS");
			return true;
		}
		catch (NGException ngE) {
			mLogger.info(ngE.toString());
			return false;
		}
	}
	
}

/*class SleepThread implements Runnable
{
	@Override
	public void run()
	{
		System.out.println("Inside SleepThread Class." );
	}
}

public class SMSAutoService
{


	public static void main(String[] args)
	{
			ThreadClient objTC = new ThreadClient();
		Thread objThread = new Thread(objTC);
		objThread.start();
	}
}*/