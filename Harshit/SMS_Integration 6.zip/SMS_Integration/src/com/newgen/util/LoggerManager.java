package com.newgen.util;

import java.io.File;
import java.io.FileInputStream;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;

import org.apache.log4j.PropertyConfigurator;

public class LoggerManager {
	
	public  void createLogFile()
	{
		try
		{
			Date date = new Date();
			DateFormat logDateFormat = new SimpleDateFormat("dd-MM-yyyy");
			String dynamicLog = "Log/"+logDateFormat.format(date)+"/SMSAutoServer.xml"; 

			Properties p = new Properties();
			p.load(new FileInputStream("log4j.properties"));  
			String orgFileName = p.getProperty("log4j.appender.mLogger.File");

			if(!(orgFileName==null || orgFileName.equalsIgnoreCase("")))
			{
				dynamicLog = "Log/"+logDateFormat.format(date)+orgFileName.substring(orgFileName.lastIndexOf("/"));
			}

			File d = new File("Log/"+logDateFormat.format(date));
			d.mkdirs();
			File fl = new File(dynamicLog);
			if(!fl.exists())
				fl.createNewFile();

			p.put("log4j.appender.mLogger.File", dynamicLog ); // overwrite "log.dir"  
			PropertyConfigurator.configure(p); 
		}
		catch(Exception e)
		{
			SMSAutoService.mLogger.info("Eexception in creating dynamic log :"+e);
			SMSAutoService.mLogger.error("Eexception in creating dynamic log :"+e);
		}
	}

}
