package com.newgen.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import org.apache.log4j.Logger;

import com.newgen.omni.wf.util.app.NGEjbClient;

public class ConfigLoader {

	public void setProperties() {
		SMSAutoService.mLogger = Logger.getLogger("mLogger");
		LoggerManager loggerManager = new LoggerManager();
		loggerManager.createLogFile();
		try {
			SMSAutoService.ngEjbClient = NGEjbClient.getSharedInstance();
		} catch (Exception e) {
			e.printStackTrace();
		}
		SMSAutoService.mLogger.info("Reading Configuration Parameters Starts");
		loadProperties();
		SMSAutoService.mLogger.info("Reading Configuration Parameters Completed");
	}

	private void loadProperties() {
		try {
			Properties p = null;
			p = new Properties();
			String strPropertyPath = "configFiles" + File.separator + "Config.properties";
			p.load(new FileInputStream(strPropertyPath));

			SMSAutoService.strQuery1 = p.getProperty("Query1");
			SMSAutoService.username = SMSAutoService.user_password.getUsername();
			SMSAutoService.password = SMSAutoService.user_password.getPassword();
			SMSAutoService.cabinetName = p.getProperty("CabinetName");
			SMSAutoService.jtsIP = p.getProperty("JTSIP");
			SMSAutoService.jtsPort = p.getProperty("JTSPort");

			SMSAutoService.ENDPOINTURL = p.getProperty("ENDPOINTURL");
			SMSAutoService.SuccessResponseCode = p.getProperty("SuccessResponseCode");
			SMSAutoService.TableName = p.getProperty("TableName");
			SMSAutoService.ColNames = p.getProperty("ColNames");
			SMSAutoService.SuccessCode = p.getProperty("SuccessCode");
			SMSAutoService.FailCode = p.getProperty("FailCode");
			SMSAutoService.select_column = p.getProperty("select_column");
			SMSAutoService.ReadCode = p.getProperty("ReadCode");

			SMSAutoService.sleepTime = Integer.parseInt(p.getProperty("sleepTime"));
			SMSAutoService.sleepTimeToWait = Integer.parseInt(p.getProperty("sleepTimeToWait"));

			SMSAutoService.TimeToRun1 = p.getProperty("TimetoRun1");
			SMSAutoService.TimeToRun2 = p.getProperty("TimetoRun2");
			SMSAutoService.TimeToRun3 = p.getProperty("TimetoRun3");

			SMSAutoService.TimeToRunFlag1 = p.getProperty("TimetoRunToGenerate1");
			SMSAutoService.TimeToRunFlag2 = p.getProperty("TimetoRunToGenerate2");
			SMSAutoService.TimeToRunFlag3 = p.getProperty("TimetoRunToGenerate3");
			SMSAutoService.SSL_Certificate_folder = p.getProperty("SSL_Certificate_folder");
			SMSAutoService.SSL_Certificate_name = p.getProperty("SSL_Certificate_name");
			SMSAutoService.SSL_password = p.getProperty("SSL_password");

			SMSAutoService.fetch_date = p.getProperty("FETCH_DATE");
		} catch (FileNotFoundException e) {
			SMSAutoService.mLogger.error("Config.properties not found. " + e);
		} catch (IOException e) {
			SMSAutoService.mLogger.error("Config.properties Load/Read Failed with IOException. " + e);
		}
	}
	
	Logger mLogger() {
		return SMSAutoService.mLogger;
	}

}
